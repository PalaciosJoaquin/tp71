<?php

class rectangulo {
  private $largo, $ancho;
  public function __construct($lar, $anc) {
  $this->largo = $lar;
  $this->ancho = $anc;
}
  public function CalcularPerimetro()
  {
    $perimetro=($this->largo*2)+($this->ancho*2);
    return $perimetro;
  }
  public function CalcularArea()
  {
    $area=$this->largo*$this->ancho;
    return $area;
  }
  public function mostrarDatos() {
  echo "Area: ". $this->CalcularArea(). "<br>Perimetro: ". $this->CalcularPerimetro();
}
}

$larg = $_POST["largo"];
$anch = $_POST["ancho"];

$rec=new rectangulo($larg,$anch);
$rec->mostrarDatos();
?>